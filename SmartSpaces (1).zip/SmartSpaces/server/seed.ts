import connectDB from './db';
import { KitCategory, Kit, FloorPlan, UserDevice } from '@shared/schema';

const sampleCategories = [
  {
    name: "Lighting",
    description: "Smart lights, switches, and lighting control systems",
    icon: "Lightbulb"
  },
  {
    name: "Security", 
    description: "Cameras, sensors, and access control devices",
    icon: "Shield"
  },
  {
    name: "Energy",
    description: "Smart thermostats, plugs, and energy monitoring",
    icon: "Zap"
  }
];

const sampleKits = [
  // Lighting Category
  {
    name: "SmartLux Pro LED Kit",
    description: "Premium smart LED bulbs with color-changing capabilities and voice control",
    price: "89.99",
    categoryName: "Lighting",
    specifications: {
      brightness: "800 lumens",
      colorRange: "16 million colors",
      powerConsumption: "9W",
      lifespan: "25,000 hours",
      connectivity: "Wi-Fi, Bluetooth"
    },
    features: ["Voice Control", "Color Changing", "Dimming", "Schedule Control", "Energy Monitoring"],
    connectivity: "Wi-Fi",
    icon: "Lightbulb",
    isActive: true
  },
  {
    name: "Motion Sensor Switch",
    description: "Automatic light switch with motion detection and ambient light sensing",
    price: "45.99",
    categoryName: "Lighting",
    specifications: {
      detectionRange: "15 feet",
      sensitivityLevels: "5 adjustable levels",
      powerRating: "600W",
      installationType: "Wall mount"
    },
    features: ["Motion Detection", "Ambient Light Sensing", "Timer Control", "Manual Override"],
    connectivity: "Zigbee",
    icon: "Lightbulb",
    isActive: true
  },
  {
    name: "Outdoor Solar Pathway Lights",
    description: "Weather-resistant solar-powered lights for pathways and gardens",
    price: "129.99",
    categoryName: "Lighting",
    specifications: {
      solarPanel: "Monocrystalline 2W",
      batteryLife: "8-12 hours",
      weatherRating: "IP65",
      installationHeight: "24 inches"
    },
    features: ["Solar Powered", "Weather Resistant", "Auto On/Off", "Warm White LED"],
    connectivity: "None",
    icon: "Lightbulb",
    isActive: true
  },

  // Security Category
  {
    name: "Guardian Pro Camera System",
    description: "4K security camera with night vision and AI-powered motion detection",
    price: "199.99",
    categoryName: "Security",
    specifications: {
      resolution: "4K Ultra HD",
      nightVision: "Up to 100 feet",
      fieldOfView: "130° wide angle",
      storage: "Cloud + Local SD card"
    },
    features: ["4K Recording", "Night Vision", "AI Motion Detection", "Two-Way Audio", "Cloud Storage"],
    connectivity: "Wi-Fi",
    icon: "Camera",
    isActive: true
  },
  {
    name: "Smart Door Lock Pro",
    description: "Keyless entry with fingerprint, code, and smartphone access",
    price: "249.99",
    categoryName: "Security",
    specifications: {
      unlockMethods: "Fingerprint, PIN, App, Key",
      fingerprintCapacity: "100 fingerprints",
      batteryLife: "6-12 months",
      compatibility: "Standard deadbolt"
    },
    features: ["Fingerprint Access", "PIN Code", "Smartphone Control", "Auto-Lock", "Guest Access"],
    connectivity: "Bluetooth, Wi-Fi",
    icon: "Lock",
    isActive: true
  },
  {
    name: "Window & Door Sensor Kit",
    description: "Wireless sensors for monitoring windows and doors with instant alerts",
    price: "69.99",
    categoryName: "Security",
    specifications: {
      range: "300 feet",
      batteryLife: "2 years",
      mountingType: "Adhesive or screws",
      compatibility: "Works with major hubs"
    },
    features: ["Instant Alerts", "Long Battery Life", "Easy Installation", "Hub Compatible"],
    connectivity: "Zigbee",
    icon: "Shield",
    isActive: true
  },

  // Energy Category
  {
    name: "EcoTherm Smart Thermostat",
    description: "Learning thermostat with energy optimization and remote control",
    price: "179.99",
    categoryName: "Energy",
    specifications: {
      compatibility: "Most HVAC systems",
      display: "Color touchscreen",
      sensors: "Temperature, humidity, occupancy",
      installation: "C-wire recommended"
    },
    features: ["Learning Algorithm", "Energy Reports", "Remote Control", "Schedule Programming", "Geofencing"],
    connectivity: "Wi-Fi",
    icon: "Thermometer",
    isActive: true
  },
  {
    name: "Smart Plug Energy Monitor",
    description: "Wi-Fi enabled smart plug with real-time energy monitoring and control",
    price: "24.99",
    categoryName: "Energy",
    specifications: {
      maxLoad: "15A/1800W",
      monitoring: "Real-time energy usage",
      size: "Compact design",
      compatibility: "Standard outlets"
    },
    features: ["Energy Monitoring", "Remote Control", "Schedule Control", "Voice Control", "Away Mode"],
    connectivity: "Wi-Fi",
    icon: "Plug",
    isActive: true
  },
  {
    name: "Solar Power Station",
    description: "Portable solar generator with battery storage for backup power",
    price: "899.99",
    categoryName: "Energy",
    specifications: {
      batteryCapacity: "1000Wh",
      solarInput: "200W max",
      outlets: "AC, USB, DC ports",
      chargingTime: "6-8 hours solar"
    },
    features: ["Portable Design", "Multiple Outlets", "Solar Charging", "Emergency Backup", "LCD Display"],
    connectivity: "None",
    icon: "Battery",
    isActive: true
  }
];

const sampleFloorPlans = [
  {
    userId: "45649344", // Using the authenticated user ID from logs
    name: "Modern Family Home",
    description: "3-bedroom house with open-plan living area",
    rooms: [
      { id: "room-1", name: "Living Room", x: 50, y: 50, width: 200, height: 150, color: "#E3F2FD" },
      { id: "room-2", name: "Kitchen", x: 270, y: 50, width: 130, height: 150, color: "#FFF3E0" },
      { id: "room-3", name: "Master Bedroom", x: 50, y: 220, width: 180, height: 120, color: "#F3E5F5" },
      { id: "room-4", name: "Guest Bedroom", x: 250, y: 220, width: 150, height: 120, color: "#E8F5E8" },
      { id: "room-5", name: "Bathroom", x: 420, y: 50, width: 80, height: 100, color: "#FFF8E1" }
    ],
    isDefault: true
  },
  {
    userId: "45649344",
    name: "Cozy Apartment",
    description: "1-bedroom urban apartment with efficient space usage",
    rooms: [
      { id: "room-1", name: "Living Area", x: 50, y: 50, width: 160, height: 120, color: "#E3F2FD" },
      { id: "room-2", name: "Kitchen", x: 230, y: 50, width: 100, height: 80, color: "#FFF3E0" },
      { id: "room-3", name: "Bedroom", x: 50, y: 190, width: 140, height: 100, color: "#F3E5F5" },
      { id: "room-4", name: "Bathroom", x: 210, y: 150, width: 70, height: 70, color: "#FFF8E1" }
    ],
    isDefault: false
  }
];

async function seedDatabase() {
  try {
    await connectDB();
    console.log('Connected to MongoDB');

    // Clear existing data
    await KitCategory.deleteMany({});
    await Kit.deleteMany({});
    await FloorPlan.deleteMany({});
    await UserDevice.deleteMany({});
    console.log('Cleared existing data');

    // Insert categories
    const insertedCategories = await KitCategory.insertMany(sampleCategories);
    console.log('Inserted kit categories');

    // Create category ID mapping
    const categoryMap = new Map();
    insertedCategories.forEach(cat => {
      categoryMap.set(cat.name, cat._id.toString());
    });

    // Insert kits with proper category IDs
    const kitsWithCategoryIds = sampleKits.map(kit => ({
      ...kit,
      categoryId: categoryMap.get(kit.categoryName)
    }));
    
    const insertedKits = await Kit.insertMany(kitsWithCategoryIds);
    console.log('Inserted kits');

    // Insert floor plans
    const insertedFloorPlans = await FloorPlan.insertMany(sampleFloorPlans);
    console.log('Inserted floor plans');

    // Create sample devices for the floor plans
    const sampleDevices = [
      // Devices for Modern Family Home
      {
        userId: "45649344",
        kitId: insertedKits[0]._id.toString(), // SmartLux Pro LED Kit
        floorPlanId: insertedFloorPlans[0]._id.toString(),
        name: "Living Room Main Light",
        roomId: "room-1",
        x: 150,
        y: 125,
        isOnline: true,
        isActive: false,
        settings: { brightness: 75, color: "#FFFFFF", schedule: "auto" }
      },
      {
        userId: "45649344", 
        kitId: insertedKits[1]._id.toString(), // Motion Sensor Switch
        floorPlanId: insertedFloorPlans[0]._id.toString(),
        name: "Kitchen Motion Switch",
        roomId: "room-2",
        x: 335,
        y: 100,
        isOnline: true,
        isActive: true,
        settings: { sensitivity: 3, timeout: 5 }
      },
      {
        userId: "45649344",
        kitId: insertedKits[3]._id.toString(), // Guardian Pro Camera
        floorPlanId: insertedFloorPlans[0]._id.toString(),
        name: "Front Door Camera",
        roomId: "room-1",
        x: 80,
        y: 80,
        isOnline: true,
        isActive: true,
        settings: { nightVision: true, motionDetection: true, recording: "continuous" }
      },
      {
        userId: "45649344",
        kitId: insertedKits[6]._id.toString(), // EcoTherm Smart Thermostat
        floorPlanId: insertedFloorPlans[0]._id.toString(),
        name: "Main Thermostat",
        roomId: "room-1",
        x: 200,
        y: 120,
        isOnline: true,
        isActive: true,
        settings: { temperature: 72, mode: "auto", schedule: "enabled" }
      },

      // Devices for Cozy Apartment
      {
        userId: "45649344",
        kitId: insertedKits[0]._id.toString(), // SmartLux Pro LED Kit
        floorPlanId: insertedFloorPlans[1]._id.toString(),
        name: "Living Area Mood Light",
        roomId: "room-1",
        x: 130,
        y: 110,
        isOnline: true,
        isActive: true,
        settings: { brightness: 60, color: "#FFE082", scene: "cozy" }
      },
      {
        userId: "45649344",
        kitId: insertedKits[4]._id.toString(), // Smart Door Lock Pro
        floorPlanId: insertedFloorPlans[1]._id.toString(),
        name: "Apartment Door Lock",
        roomId: "room-1",
        x: 60,
        y: 60,
        isOnline: true,
        isActive: false,
        settings: { autoLock: true, guestAccess: false }
      },
      {
        userId: "45649344",
        kitId: insertedKits[7]._id.toString(), // Smart Plug Energy Monitor
        floorPlanId: insertedFloorPlans[1]._id.toString(),
        name: "Living Room Smart Plug",
        roomId: "room-1",
        x: 180,
        y: 140,
        isOnline: true,
        isActive: true,
        settings: { energyMonitoring: true, schedule: "enabled" }
      },
      {
        userId: "45649344",
        kitId: insertedKits[5]._id.toString(), // Window & Door Sensor
        floorPlanId: insertedFloorPlans[1]._id.toString(),
        name: "Bedroom Window Sensor",
        roomId: "room-3",
        x: 120,
        y: 220,
        isOnline: true,
        isActive: true,
        settings: { alerts: true, sensitivity: "high" }
      }
    ];

    await UserDevice.insertMany(sampleDevices);
    console.log('Inserted user devices');

    console.log('✅ Database seeded successfully with comprehensive dummy data!');
    console.log(`📊 Seeded: ${insertedCategories.length} categories, ${insertedKits.length} kits, ${insertedFloorPlans.length} floor plans, ${sampleDevices.length} devices`);
    
  } catch (error) {
    console.error('❌ Error seeding database:', error);
  }
}

seedDatabase();