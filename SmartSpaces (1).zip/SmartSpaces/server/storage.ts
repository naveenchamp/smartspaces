import {
  User,
  Kit,
  KitCategory,
  FloorPlan,
  UserDevice,
  type User as UserType,
  type UpsertUser,
  type Kit as KitType,
  type KitCategory as KitCategoryType,
  type FloorPlan as FloorPlanType,
  type InsertFloorPlan,
  type UserDevice as UserDeviceType,
  type InsertUserDevice,
} from "@shared/schema";
import connectDB from "./db";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<UserType | undefined>;
  upsertUser(user: UpsertUser): Promise<UserType>;
  
  // Kit operations
  getKitCategories(): Promise<KitCategoryType[]>;
  getKitsByCategory(categoryId: string): Promise<KitType[]>;
  getAllKits(): Promise<KitType[]>;
  getKit(id: string): Promise<KitType | undefined>;
  
  // Floor plan operations
  getUserFloorPlans(userId: string): Promise<FloorPlanType[]>;
  getFloorPlan(id: string): Promise<FloorPlanType | undefined>;
  createFloorPlan(floorPlan: InsertFloorPlan): Promise<FloorPlanType>;
  updateFloorPlan(id: string, updates: Partial<InsertFloorPlan>): Promise<FloorPlanType>;
  deleteFloorPlan(id: string): Promise<void>;
  
  // User device operations
  getUserDevices(userId: string, floorPlanId?: string): Promise<UserDeviceType[]>;
  createUserDevice(device: InsertUserDevice): Promise<UserDeviceType>;
  updateUserDevice(id: string, updates: Partial<InsertUserDevice>): Promise<UserDeviceType>;
  deleteUserDevice(id: string): Promise<void>;
  
  // Data seeding (optional for memory storage)
  seedUserData?(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<UserType | undefined> {
    await connectDB();
    const user = await User.findOne({ id }).lean();
    return user ? { ...user, _id: user._id.toString() } : undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<UserType> {
    await connectDB();
    const user = await User.findOneAndUpdate(
      { id: userData.id },
      { ...userData, updatedAt: new Date() },
      { upsert: true, new: true }
    ).lean();
    return { ...user, _id: user._id.toString() };
  }

  // Kit operations
  async getKitCategories(): Promise<KitCategoryType[]> {
    await connectDB();
    const categories = await KitCategory.find().lean();
    return categories.map(cat => ({ ...cat, _id: cat._id.toString() }));
  }

  async getKitsByCategory(categoryId: string): Promise<KitType[]> {
    await connectDB();
    const kits = await Kit.find({ categoryId }).lean();
    return kits.map(kit => ({ ...kit, _id: kit._id.toString() }));
  }

  async getAllKits(): Promise<KitType[]> {
    await connectDB();
    const kits = await Kit.find({ isActive: true }).lean();
    return kits.map(kit => ({ ...kit, _id: kit._id.toString() }));
  }

  async getKit(id: string): Promise<KitType | undefined> {
    await connectDB();
    const kit = await Kit.findById(id).lean();
    return kit ? { ...kit, _id: kit._id.toString() } : undefined;
  }

  // Floor plan operations
  async getUserFloorPlans(userId: string): Promise<FloorPlanType[]> {
    await connectDB();
    const plans = await FloorPlan.find({ userId }).lean();
    return plans.map(plan => ({ ...plan, _id: plan._id.toString() }));
  }

  async getFloorPlan(id: string): Promise<FloorPlanType | undefined> {
    await connectDB();
    const plan = await FloorPlan.findById(id).lean();
    return plan ? { ...plan, _id: plan._id.toString() } : undefined;
  }

  async createFloorPlan(floorPlan: InsertFloorPlan): Promise<FloorPlanType> {
    await connectDB();
    const created = await FloorPlan.create(floorPlan);
    return { ...created.toObject(), _id: created._id.toString() };
  }

  async updateFloorPlan(id: string, updates: Partial<InsertFloorPlan>): Promise<FloorPlanType> {
    await connectDB();
    const updated = await FloorPlan.findByIdAndUpdate(
      id,
      { ...updates, updatedAt: new Date() },
      { new: true }
    ).lean();
    if (!updated) throw new Error('Floor plan not found');
    return { ...updated, _id: updated._id.toString() };
  }

  async deleteFloorPlan(id: string): Promise<void> {
    await connectDB();
    await FloorPlan.findByIdAndDelete(id);
  }

  // User device operations
  async getUserDevices(userId: string, floorPlanId?: string): Promise<UserDeviceType[]> {
    await connectDB();
    const query = floorPlanId ? { userId, floorPlanId } : { userId };
    const devices = await UserDevice.find(query).lean();
    return devices.map(device => ({ ...device, _id: device._id.toString() }));
  }

  async createUserDevice(device: InsertUserDevice): Promise<UserDeviceType> {
    await connectDB();
    const created = await UserDevice.create(device);
    return { ...created.toObject(), _id: created._id.toString() };
  }

  async updateUserDevice(id: string, updates: Partial<InsertUserDevice>): Promise<UserDeviceType> {
    await connectDB();
    const updated = await UserDevice.findByIdAndUpdate(
      id,
      { ...updates, lastUpdate: new Date() },
      { new: true }
    ).lean();
    if (!updated) throw new Error('Device not found');
    return { ...updated, _id: updated._id.toString() };
  }

  async deleteUserDevice(id: string): Promise<void> {
    await connectDB();
    await UserDevice.findByIdAndDelete(id);
  }
}

import { MemoryStorage } from "./memoryStorage";

export const storage = new MemoryStorage();