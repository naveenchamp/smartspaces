import {
  type User as UserType,
  type UpsertUser,
  type Kit as KitType,
  type KitCategory as KitCategoryType,
  type FloorPlan as FloorPlanType,
  type InsertFloorPlan,
  type UserDevice as UserDeviceType,
  type InsertUserDevice,
} from "@shared/schema";
import { IStorage } from "./storage";

// In-memory storage for development
let users: Map<string, UserType> = new Map();
let kitCategories: Map<string, KitCategoryType> = new Map();
let kits: Map<string, KitType> = new Map();
let floorPlans: Map<string, FloorPlanType> = new Map();
let userDevices: Map<string, UserDeviceType> = new Map();

// Initialize with comprehensive dummy data
function initializeData() {
  // Categories
  const categories = [
    {
      _id: "cat-1",
      name: "Lighting",
      description: "Smart lights, switches, and lighting control systems",
      icon: "Lightbulb",
      createdAt: new Date()
    },
    {
      _id: "cat-2", 
      name: "Security",
      description: "Cameras, sensors, and access control devices",
      icon: "Shield",
      createdAt: new Date()
    },
    {
      _id: "cat-3",
      name: "Energy",
      description: "Smart thermostats, plugs, and energy monitoring",
      icon: "Zap",
      createdAt: new Date()
    }
  ];

  categories.forEach(cat => kitCategories.set(cat._id, cat));

  // Kits with comprehensive data
  const kitsData = [
    // Lighting Category
    {
      _id: "kit-1",
      name: "SmartLux Pro LED Kit",
      description: "Premium smart LED bulbs with color-changing capabilities and voice control",
      price: "89.99",
      categoryId: "cat-1",
      specifications: {
        brightness: "800 lumens",
        colorRange: "16 million colors",
        powerConsumption: "9W",
        lifespan: "25,000 hours",
        connectivity: "Wi-Fi, Bluetooth"
      },
      features: ["Voice Control", "Color Changing", "Dimming", "Schedule Control", "Energy Monitoring"],
      connectivity: "Wi-Fi",
      icon: "Lightbulb",
      isActive: true,
      createdAt: new Date()
    },
    {
      _id: "kit-2",
      name: "Motion Sensor Switch",
      description: "Automatic light switch with motion detection and ambient light sensing",
      price: "45.99",
      categoryId: "cat-1",
      specifications: {
        detectionRange: "15 feet",
        sensitivityLevels: "5 adjustable levels",
        powerRating: "600W",
        installationType: "Wall mount"
      },
      features: ["Motion Detection", "Ambient Light Sensing", "Timer Control", "Manual Override"],
      connectivity: "Zigbee",
      icon: "Lightbulb",
      isActive: true,
      createdAt: new Date()
    },
    {
      _id: "kit-3",
      name: "Outdoor Solar Pathway Lights",
      description: "Weather-resistant solar-powered lights for pathways and gardens",
      price: "129.99",
      categoryId: "cat-1",
      specifications: {
        solarPanel: "Monocrystalline 2W",
        batteryLife: "8-12 hours",
        weatherRating: "IP65",
        installationHeight: "24 inches"
      },
      features: ["Solar Powered", "Weather Resistant", "Auto On/Off", "Warm White LED"],
      connectivity: "None",
      icon: "Lightbulb",
      isActive: true,
      createdAt: new Date()
    },
    // Security Category
    {
      _id: "kit-4",
      name: "Guardian Pro Camera System",
      description: "4K security camera with night vision and AI-powered motion detection",
      price: "199.99",
      categoryId: "cat-2",
      specifications: {
        resolution: "4K Ultra HD",
        nightVision: "Up to 100 feet",
        fieldOfView: "130° wide angle",
        storage: "Cloud + Local SD card"
      },
      features: ["4K Recording", "Night Vision", "AI Motion Detection", "Two-Way Audio", "Cloud Storage"],
      connectivity: "Wi-Fi",
      icon: "Camera",
      isActive: true,
      createdAt: new Date()
    },
    {
      _id: "kit-5",
      name: "Smart Door Lock Pro",
      description: "Keyless entry with fingerprint, code, and smartphone access",
      price: "249.99",
      categoryId: "cat-2",
      specifications: {
        unlockMethods: "Fingerprint, PIN, App, Key",
        fingerprintCapacity: "100 fingerprints",
        batteryLife: "6-12 months",
        compatibility: "Standard deadbolt"
      },
      features: ["Fingerprint Access", "PIN Code", "Smartphone Control", "Auto-Lock", "Guest Access"],
      connectivity: "Bluetooth, Wi-Fi",
      icon: "Lock",
      isActive: true,
      createdAt: new Date()
    },
    {
      _id: "kit-6",
      name: "Window & Door Sensor Kit",
      description: "Wireless sensors for monitoring windows and doors with instant alerts",
      price: "69.99",
      categoryId: "cat-2",
      specifications: {
        range: "300 feet",
        batteryLife: "2 years",
        mountingType: "Adhesive or screws",
        compatibility: "Works with major hubs"
      },
      features: ["Instant Alerts", "Long Battery Life", "Easy Installation", "Hub Compatible"],
      connectivity: "Zigbee",
      icon: "Shield",
      isActive: true,
      createdAt: new Date()
    },
    // Energy Category
    {
      _id: "kit-7",
      name: "EcoTherm Smart Thermostat",
      description: "Learning thermostat with energy optimization and remote control",
      price: "179.99",
      categoryId: "cat-3",
      specifications: {
        compatibility: "Most HVAC systems",
        display: "Color touchscreen",
        sensors: "Temperature, humidity, occupancy",
        installation: "C-wire recommended"
      },
      features: ["Learning Algorithm", "Energy Reports", "Remote Control", "Schedule Programming", "Geofencing"],
      connectivity: "Wi-Fi",
      icon: "Thermometer",
      isActive: true,
      createdAt: new Date()
    },
    {
      _id: "kit-8",
      name: "Smart Plug Energy Monitor",
      description: "Wi-Fi enabled smart plug with real-time energy monitoring and control",
      price: "24.99",
      categoryId: "cat-3",
      specifications: {
        maxLoad: "15A/1800W",
        monitoring: "Real-time energy usage",
        size: "Compact design",
        compatibility: "Standard outlets"
      },
      features: ["Energy Monitoring", "Remote Control", "Schedule Control", "Voice Control", "Away Mode"],
      connectivity: "Wi-Fi",
      icon: "Plug",
      isActive: true,
      createdAt: new Date()
    },
    {
      _id: "kit-9",
      name: "Solar Power Station",
      description: "Portable solar generator with battery storage for backup power",
      price: "899.99",
      categoryId: "cat-3",
      specifications: {
        batteryCapacity: "1000Wh",
        solarInput: "200W max",
        outlets: "AC, USB, DC ports",
        chargingTime: "6-8 hours solar"
      },
      features: ["Portable Design", "Multiple Outlets", "Solar Charging", "Emergency Backup", "LCD Display"],
      connectivity: "None",
      icon: "Battery",
      isActive: true,
      createdAt: new Date()
    }
  ];

  kitsData.forEach(kit => kits.set(kit._id, kit));
}

// Initialize data on module load
initializeData();

export class MemoryStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<UserType | undefined> {
    return users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<UserType> {
    const existingUser = users.get(userData.id);
    const user: UserType = {
      _id: userData.id,
      ...userData,
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date()
    };
    users.set(userData.id, user);
    return user;
  }

  // Kit operations
  async getKitCategories(): Promise<KitCategoryType[]> {
    return Array.from(kitCategories.values());
  }

  async getKitsByCategory(categoryId: string): Promise<KitType[]> {
    return Array.from(kits.values()).filter(kit => kit.categoryId === categoryId);
  }

  async getAllKits(): Promise<KitType[]> {
    return Array.from(kits.values()).filter(kit => kit.isActive);
  }

  async getKit(id: string): Promise<KitType | undefined> {
    return kits.get(id);
  }

  // Floor plan operations
  async getUserFloorPlans(userId: string): Promise<FloorPlanType[]> {
    return Array.from(floorPlans.values()).filter(plan => plan.userId === userId);
  }

  async getFloorPlan(id: string): Promise<FloorPlanType | undefined> {
    return floorPlans.get(id);
  }

  async createFloorPlan(floorPlan: InsertFloorPlan): Promise<FloorPlanType> {
    const id = `plan-${Date.now()}`;
    const created: FloorPlanType = {
      _id: id,
      ...floorPlan,
      isDefault: floorPlan.isDefault || false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    floorPlans.set(id, created);
    return created;
  }

  async updateFloorPlan(id: string, updates: Partial<InsertFloorPlan>): Promise<FloorPlanType> {
    const existing = floorPlans.get(id);
    if (!existing) throw new Error('Floor plan not found');
    
    const updated: FloorPlanType = {
      ...existing,
      ...updates,
      updatedAt: new Date()
    };
    floorPlans.set(id, updated);
    return updated;
  }

  async deleteFloorPlan(id: string): Promise<void> {
    floorPlans.delete(id);
    // Also delete associated devices
    const devicesToDelete = Array.from(userDevices.entries())
      .filter(([_, device]) => device.floorPlanId === id)
      .map(([deviceId, _]) => deviceId);
    
    devicesToDelete.forEach(deviceId => userDevices.delete(deviceId));
  }

  // User device operations
  async getUserDevices(userId: string, floorPlanId?: string): Promise<UserDeviceType[]> {
    return Array.from(userDevices.values()).filter(device => {
      if (device.userId !== userId) return false;
      if (floorPlanId && device.floorPlanId !== floorPlanId) return false;
      return true;
    });
  }

  async createUserDevice(device: InsertUserDevice): Promise<UserDeviceType> {
    const id = `device-${Date.now()}`;
    const created: UserDeviceType = {
      _id: id,
      ...device,
      isOnline: device.isOnline || true,
      isActive: device.isActive || false,
      lastUpdate: new Date(),
      createdAt: new Date()
    };
    userDevices.set(id, created);
    return created;
  }

  async updateUserDevice(id: string, updates: Partial<InsertUserDevice>): Promise<UserDeviceType> {
    const existing = userDevices.get(id);
    if (!existing) throw new Error('Device not found');
    
    const updated: UserDeviceType = {
      ...existing,
      ...updates,
      lastUpdate: new Date()
    };
    userDevices.set(id, updated);
    return updated;
  }

  async deleteUserDevice(id: string): Promise<void> {
    userDevices.delete(id);
  }

  // Method to seed sample floor plans and devices for a user
  async seedUserData(userId: string): Promise<void> {
    // Create sample floor plans
    const floorPlan1 = await this.createFloorPlan({
      userId,
      name: "Modern Family Home",
      description: "3-bedroom house with open-plan living area",
      rooms: [
        { id: "room-1", name: "Living Room", x: 50, y: 50, width: 200, height: 150, color: "#E3F2FD" },
        { id: "room-2", name: "Kitchen", x: 270, y: 50, width: 130, height: 150, color: "#FFF3E0" },
        { id: "room-3", name: "Master Bedroom", x: 50, y: 220, width: 180, height: 120, color: "#F3E5F5" },
        { id: "room-4", name: "Guest Bedroom", x: 250, y: 220, width: 150, height: 120, color: "#E8F5E8" },
        { id: "room-5", name: "Bathroom", x: 420, y: 50, width: 80, height: 100, color: "#FFF8E1" }
      ],
      isDefault: true
    });

    const floorPlan2 = await this.createFloorPlan({
      userId,
      name: "Cozy Apartment",
      description: "1-bedroom urban apartment with efficient space usage",
      rooms: [
        { id: "room-1", name: "Living Area", x: 50, y: 50, width: 160, height: 120, color: "#E3F2FD" },
        { id: "room-2", name: "Kitchen", x: 230, y: 50, width: 100, height: 80, color: "#FFF3E0" },
        { id: "room-3", name: "Bedroom", x: 50, y: 190, width: 140, height: 100, color: "#F3E5F5" },
        { id: "room-4", name: "Bathroom", x: 210, y: 150, width: 70, height: 70, color: "#FFF8E1" }
      ],
      isDefault: false
    });

    // Create sample devices
    const sampleDevices = [
      // Devices for Modern Family Home
      {
        userId,
        kitId: "kit-1", // SmartLux Pro LED Kit
        floorPlanId: floorPlan1._id,
        name: "Living Room Main Light",
        roomId: "room-1",
        x: 150,
        y: 125,
        isOnline: true,
        isActive: false,
        settings: { brightness: 75, color: "#FFFFFF", schedule: "auto" }
      },
      {
        userId,
        kitId: "kit-2", // Motion Sensor Switch
        floorPlanId: floorPlan1._id,
        name: "Kitchen Motion Switch",
        roomId: "room-2",
        x: 335,
        y: 100,
        isOnline: true,
        isActive: true,
        settings: { sensitivity: 3, timeout: 5 }
      },
      {
        userId,
        kitId: "kit-4", // Guardian Pro Camera
        floorPlanId: floorPlan1._id,
        name: "Front Door Camera",
        roomId: "room-1",
        x: 80,
        y: 80,
        isOnline: true,
        isActive: true,
        settings: { nightVision: true, motionDetection: true, recording: "continuous" }
      },
      {
        userId,
        kitId: "kit-7", // EcoTherm Smart Thermostat
        floorPlanId: floorPlan1._id,
        name: "Main Thermostat",
        roomId: "room-1",
        x: 200,
        y: 120,
        isOnline: true,
        isActive: true,
        settings: { temperature: 72, mode: "auto", schedule: "enabled" }
      },
      // Devices for Cozy Apartment
      {
        userId,
        kitId: "kit-1", // SmartLux Pro LED Kit
        floorPlanId: floorPlan2._id,
        name: "Living Area Mood Light",
        roomId: "room-1",
        x: 130,
        y: 110,
        isOnline: true,
        isActive: true,
        settings: { brightness: 60, color: "#FFE082", scene: "cozy" }
      },
      {
        userId,
        kitId: "kit-5", // Smart Door Lock Pro
        floorPlanId: floorPlan2._id,
        name: "Apartment Door Lock",
        roomId: "room-1",
        x: 60,
        y: 60,
        isOnline: true,
        isActive: false,
        settings: { autoLock: true, guestAccess: false }
      },
      {
        userId,
        kitId: "kit-8", // Smart Plug Energy Monitor
        floorPlanId: floorPlan2._id,
        name: "Living Room Smart Plug",
        roomId: "room-1",
        x: 180,
        y: 140,
        isOnline: true,
        isActive: true,
        settings: { energyMonitoring: true, schedule: "enabled" }
      },
      {
        userId,
        kitId: "kit-6", // Window & Door Sensor
        floorPlanId: floorPlan2._id,
        name: "Bedroom Window Sensor",
        roomId: "room-3",
        x: 120,
        y: 220,
        isOnline: true,
        isActive: true,
        settings: { alerts: true, sensitivity: "high" }
      }
    ];

    // Create all devices
    for (const deviceData of sampleDevices) {
      await this.createUserDevice(deviceData);
    }
  }
}