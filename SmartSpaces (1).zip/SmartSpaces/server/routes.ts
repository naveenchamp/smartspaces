import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertFloorPlanSchema, insertUserDeviceSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Kit routes
  app.get('/api/kit-categories', async (req, res) => {
    try {
      const categories = await storage.getKitCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching kit categories:", error);
      res.status(500).json({ message: "Failed to fetch kit categories" });
    }
  });

  app.get('/api/kits', async (req, res) => {
    try {
      const { categoryId } = req.query;
      
      if (categoryId && typeof categoryId === 'string') {
        const kits = await storage.getKitsByCategory(categoryId);
        res.json(kits);
      } else {
        const kits = await storage.getAllKits();
        res.json(kits);
      }
    } catch (error) {
      console.error("Error fetching kits:", error);
      res.status(500).json({ message: "Failed to fetch kits" });
    }
  });

  app.get('/api/kits/:id', async (req, res) => {
    try {
      const kit = await storage.getKit(req.params.id);
      if (!kit) {
        return res.status(404).json({ message: "Kit not found" });
      }
      res.json(kit);
    } catch (error) {
      console.error("Error fetching kit:", error);
      res.status(500).json({ message: "Failed to fetch kit" });
    }
  });

  // Floor plan routes
  app.get('/api/floor-plans', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const floorPlans = await storage.getUserFloorPlans(userId);
      res.json(floorPlans);
    } catch (error) {
      console.error("Error fetching floor plans:", error);
      res.status(500).json({ message: "Failed to fetch floor plans" });
    }
  });

  app.post('/api/floor-plans', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const floorPlanData = insertFloorPlanSchema.parse({
        ...req.body,
        userId,
      });
      
      const floorPlan = await storage.createFloorPlan(floorPlanData);
      res.status(201).json(floorPlan);
    } catch (error) {
      console.error("Error creating floor plan:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid floor plan data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create floor plan" });
    }
  });

  app.put('/api/floor-plans/:id', isAuthenticated, async (req: any, res) => {
    try {
      const updates = insertFloorPlanSchema.partial().parse(req.body);
      const floorPlan = await storage.updateFloorPlan(req.params.id, updates);
      res.json(floorPlan);
    } catch (error) {
      console.error("Error updating floor plan:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid floor plan data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update floor plan" });
    }
  });

  app.delete('/api/floor-plans/:id', isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteFloorPlan(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting floor plan:", error);
      res.status(500).json({ message: "Failed to delete floor plan" });
    }
  });

  // User device routes
  app.get('/api/devices', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { floorPlanId } = req.query;
      
      const devices = await storage.getUserDevices(
        userId, 
        floorPlanId ? String(floorPlanId) : undefined
      );
      res.json(devices);
    } catch (error) {
      console.error("Error fetching devices:", error);
      res.status(500).json({ message: "Failed to fetch devices" });
    }
  });

  app.post('/api/devices', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const deviceData = insertUserDeviceSchema.parse({
        ...req.body,
        userId,
      });
      
      const device = await storage.createUserDevice(deviceData);
      res.status(201).json(device);
    } catch (error) {
      console.error("Error creating device:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid device data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create device" });
    }
  });

  app.put('/api/devices/:id', isAuthenticated, async (req: any, res) => {
    try {
      const updates = insertUserDeviceSchema.partial().parse(req.body);
      const device = await storage.updateUserDevice(req.params.id, updates);
      res.json(device);
    } catch (error) {
      console.error("Error updating device:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid device data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update device" });
    }
  });

  app.delete('/api/devices/:id', isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteUserDevice(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting device:", error);
      res.status(500).json({ message: "Failed to delete device" });
    }
  });

  // Seed data route (for development)
  app.post('/api/seed', async (req, res) => {
    try {
      const { db } = await import("./db");
      const { kitCategories, kits: kitsTable, floorPlans, userDevices } = await import("@shared/schema");
      
      // Insert kit categories
      const categories = [
        {
          name: "Lighting",
          description: "Smart lighting solutions with RGB LED strips and controls",
          icon: "lightbulb"
        },
        {
          name: "Security", 
          description: "Motion sensors, cameras, and security automation",
          icon: "shield-alt"
        },
        {
          name: "Energy",
          description: "Climate control, thermostats, and energy monitoring",
          icon: "bolt"
        }
      ];
      
      const createdCategories = [];
      for (const category of categories) {
        const [created] = await db.insert(kitCategories).values(category).returning();
        createdCategories.push(created);
      }

      // Insert comprehensive kit collection
      const kits = [
        // Lighting Category
        {
          name: "Smart RGB Lighting Kit",
          description: "ESP32-based addressable LED controller with mobile app integration",
          price: "89.00",
          categoryId: createdCategories[0].id,
          specifications: {
            controller: "ESP32 DevKit",
            leds: "SK6812 RGB LEDs",
            connectivity: "Wi-Fi + Bluetooth",
            power: "12V 5A",
            range: "16.7M colors"
          },
          features: ["16.7M colors, dimming control", "Wi-Fi + Bluetooth connectivity", "Voice control compatible"],
          connectivity: "Wi-Fi, Bluetooth",
          icon: "lightbulb"
        },
        {
          name: "Smart Switch Kit",
          description: "Wi-Fi enabled smart switch with touch controls and scheduling",
          price: "45.00",
          categoryId: createdCategories[0].id,
          specifications: {
            controller: "ESP8266",
            switch: "Capacitive touch",
            voltage: "110-240V AC",
            load: "10A max",
            connectivity: "Wi-Fi"
          },
          features: ["Touch controls", "Schedule automation", "Remote control via app"],
          connectivity: "Wi-Fi",
          icon: "toggle-on"
        },
        {
          name: "LED Strip Starter Kit",
          description: "5m addressable LED strip with controller and power supply",
          price: "120.00",
          categoryId: createdCategories[0].id,
          specifications: {
            length: "5 meters",
            leds: "WS2812B RGB LEDs",
            density: "60 LEDs/meter",
            power: "12V 10A supply included",
            controller: "Arduino compatible"
          },
          features: ["300 addressable LEDs", "Weatherproof coating", "Multiple animation modes"],
          connectivity: "Wi-Fi",
          icon: "lightbulb"
        },
        // Security Category
        {
          name: "Motion Security Kit",
          description: "PIR motion detection with instant mobile alerts and automation",
          price: "65.00",
          categoryId: createdCategories[1].id,
          specifications: {
            sensor: "AM312 PIR Motion Sensor",
            controller: "ESP32 DevKit",
            range: "12m detection range",
            power: "Battery + AC adapter",
            connectivity: "Wi-Fi"
          },
          features: ["12m detection range", "Real-time notifications", "Battery backup included"],
          connectivity: "Wi-Fi",
          icon: "running"
        },
        {
          name: "Door/Window Sensor Kit",
          description: "Magnetic reed switches for monitoring entry points",
          price: "35.00",
          categoryId: createdCategories[1].id,
          specifications: {
            sensor: "Reed switch + magnet",
            controller: "ESP32-C3",
            battery: "CR2032 (2 year life)",
            range: "100m open air",
            connectivity: "Wi-Fi"
          },
          features: ["Ultra-low power", "Tamper detection", "Easy installation"],
          connectivity: "Wi-Fi",
          icon: "door-open"
        },
        {
          name: "Security Camera Kit",
          description: "HD camera with night vision and motion recording",
          price: "180.00",
          categoryId: createdCategories[1].id,
          specifications: {
            resolution: "1080p HD",
            camera: "OV2640 sensor",
            storage: "MicroSD up to 128GB",
            nightvision: "IR LEDs included",
            connectivity: "Wi-Fi + Ethernet"
          },
          features: ["1080p HD recording", "Night vision", "Motion-triggered recording"],
          connectivity: "Wi-Fi, Ethernet",
          icon: "video"
        },
        // Energy Category
        {
          name: "Climate Control Kit",
          description: "DHT sensor with relay control for HVAC automation",
          price: "129.00",
          categoryId: createdCategories[2].id,
          specifications: {
            sensor: "DHT22 Temperature/Humidity",
            controller: "ESP32 DevKit",
            relays: "4-channel relay module",
            accuracy: "±0.5°C, ±2-5% RH",
            connectivity: "Wi-Fi"
          },
          features: ["Temperature & humidity sensing", "Programmable schedules", "Energy usage tracking"],
          connectivity: "Wi-Fi",
          icon: "thermometer-half"
        },
        {
          name: "Smart Thermostat Kit",
          description: "Programmable thermostat with learning algorithms",
          price: "199.00",
          categoryId: createdCategories[2].id,
          specifications: {
            display: "3.5\" color touchscreen",
            sensors: "Temperature, humidity, occupancy",
            compatibility: "Most HVAC systems",
            controller: "ESP32-S3",
            connectivity: "Wi-Fi + Bluetooth"
          },
          features: ["Learning algorithms", "Geofencing", "Energy reports"],
          connectivity: "Wi-Fi, Bluetooth",
          icon: "thermometer-half"
        },
        {
          name: "Smart Outlet Kit",
          description: "Wi-Fi enabled outlet with energy monitoring",
          price: "55.00",
          categoryId: createdCategories[2].id,
          specifications: {
            rating: "15A, 120V",
            controller: "ESP8266",
            monitoring: "Voltage, current, power",
            safety: "Surge protection built-in",
            connectivity: "Wi-Fi"
          },
          features: ["Energy monitoring", "Surge protection", "Schedule control"],
          connectivity: "Wi-Fi",
          icon: "plug"
        }
      ];
      
      const createdKits = [];
      for (const kit of kits) {
        const [created] = await db.insert(kitsTable).values(kit).returning();
        createdKits.push(created);
      }

      // Create sample floor plans for demonstration
      const sampleFloorPlans = [
        {
          userId: "demo-user-id",
          name: "Main Floor",
          rooms: [
            { id: "living", name: "Living Room", x: 50, y: 50, width: 300, height: 200 },
            { id: "kitchen", name: "Kitchen", x: 400, y: 50, width: 250, height: 200 },
            { id: "bedroom", name: "Bedroom", x: 50, y: 300, width: 200, height: 200 },
            { id: "bathroom", name: "Bathroom", x: 300, y: 300, width: 150, height: 150 }
          ]
        },
        {
          userId: "demo-user-id", 
          name: "Second Floor",
          rooms: [
            { id: "master", name: "Master Bedroom", x: 50, y: 50, width: 350, height: 250 },
            { id: "guest", name: "Guest Room", x: 450, y: 50, width: 200, height: 200 },
            { id: "office", name: "Home Office", x: 50, y: 350, width: 200, height: 150 }
          ]
        }
      ];

      const createdFloorPlans = [];
      for (const plan of sampleFloorPlans) {
        const [created] = await db.insert(floorPlans).values(plan).returning();
        createdFloorPlans.push(created);
      }

      // Create sample devices placed in floor plans
      const sampleDevices = [
        // Living Room devices
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[0].id,
          kitId: createdKits[0].id, // Smart RGB Lighting
          roomId: "living",
          name: "Living Room Accent Lights",
          x: 200,
          y: 100,
          isOnline: true,
          isActive: true,
          settings: { brightness: 80, color: "#ff6b35", mode: "ambient" }
        },
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[0].id,
          kitId: createdKits[3].id, // Motion Security Kit
          roomId: "living",
          name: "Living Room Motion Sensor",
          x: 100,
          y: 150,
          isOnline: true,
          isActive: true,
          settings: { sensitivity: "medium", alerts: true }
        },
        // Kitchen devices
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[0].id,
          kitId: createdKits[1].id, // Smart Switch
          roomId: "kitchen",
          name: "Kitchen Lights Switch",
          x: 500,
          y: 100,
          isOnline: true,
          isActive: false,
          settings: { schedule: "auto", dimLevel: 100 }
        },
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[0].id,
          kitId: createdKits[8].id, // Smart Outlet
          roomId: "kitchen",
          name: "Coffee Maker Outlet",
          x: 550,
          y: 150,
          isOnline: true,
          isActive: true,
          settings: { schedule: "6:30 AM", powerUsage: "850W" }
        },
        // Bedroom devices
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[0].id,
          kitId: createdKits[6].id, // Climate Control
          roomId: "bedroom",
          name: "Bedroom Climate Control",
          x: 150,
          y: 400,
          isOnline: true,
          isActive: true,
          settings: { temperature: 72, humidity: 45, mode: "auto" }
        },
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[0].id,
          kitId: createdKits[4].id, // Door/Window Sensor
          roomId: "bedroom",
          name: "Bedroom Window Sensor",
          x: 200,
          y: 350,
          isOnline: true,
          isActive: true,
          settings: { alerts: true, armed: true }
        },
        // Second floor devices
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[1].id,
          kitId: createdKits[7].id, // Smart Thermostat
          roomId: "master",
          name: "Master Bedroom Thermostat",
          x: 200,
          y: 150,
          isOnline: true,
          isActive: true,
          settings: { targetTemp: 70, schedule: "smart", learningMode: true }
        },
        {
          userId: "demo-user-id",
          floorPlanId: createdFloorPlans[1].id,
          kitId: createdKits[2].id, // LED Strip
          roomId: "office",
          name: "Office Desk Lighting",
          x: 150,
          y: 400,
          isOnline: false,
          isActive: false,
          settings: { color: "#4a90e2", pattern: "solid", brightness: 60 }
        }
      ];

      for (const device of sampleDevices) {
        await db.insert(userDevices).values(device);
      }

      res.json({ 
        message: "Comprehensive seed data created successfully",
        summary: {
          categories: createdCategories.length,
          kits: createdKits.length,
          floorPlans: createdFloorPlans.length,
          devices: sampleDevices.length
        }
      });
    } catch (error) {
      console.error("Error seeding data:", error);
      res.status(500).json({ message: "Failed to seed data" });
    }
  });

  // Seed user-specific data (requires authentication)
  app.post('/api/seed-user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { db } = await import("./db");
      const { floorPlans, userDevices, kits: kitsTable } = await import("@shared/schema");
      
      // Get available kits to reference
      const availableKits = await db.select().from(kitsTable);
      
      // Create personalized floor plans for the authenticated user
      const userFloorPlans = [
        {
          userId,
          name: "My Smart Home",
          rooms: [
            { id: "living", name: "Living Room", x: 50, y: 50, width: 350, height: 250 },
            { id: "kitchen", name: "Kitchen", x: 450, y: 50, width: 300, height: 200 },
            { id: "master", name: "Master Bedroom", x: 50, y: 350, width: 250, height: 200 },
            { id: "guest", name: "Guest Room", x: 350, y: 350, width: 200, height: 150 },
            { id: "office", name: "Home Office", x: 600, y: 350, width: 150, height: 150 }
          ]
        },
        {
          userId,
          name: "Apartment Layout",
          rooms: [
            { id: "studio", name: "Studio Space", x: 50, y: 50, width: 400, height: 300 },
            { id: "kitchen", name: "Kitchenette", x: 500, y: 50, width: 200, height: 150 },
            { id: "bathroom", name: "Bathroom", x: 500, y: 250, width: 150, height: 100 }
          ]
        }
      ];

      const createdUserPlans = [];
      for (const plan of userFloorPlans) {
        const [created] = await db.insert(floorPlans).values(plan).returning();
        createdUserPlans.push(created);
      }

      // Create personalized devices for the user
      const userDevicesData = [
        // Smart Home Plan devices
        {
          userId,
          floorPlanId: createdUserPlans[0].id,
          kitId: availableKits[0]?.id, // First available kit
          roomId: "living",
          name: "Main Living Lights",
          x: 200,
          y: 150,
          isOnline: true,
          isActive: true,
          settings: { brightness: 75, color: "#ffffff", mode: "normal" }
        },
        {
          userId,
          floorPlanId: createdUserPlans[0].id,
          kitId: availableKits[3]?.id, // Security kit
          roomId: "living",
          name: "Front Door Motion",
          x: 100,
          y: 200,
          isOnline: true,
          isActive: true,
          settings: { sensitivity: "high", notifications: true }
        },
        {
          userId,
          floorPlanId: createdUserPlans[0].id,
          kitId: availableKits[6]?.id, // Climate kit
          roomId: "master",
          name: "Bedroom Thermostat",
          x: 150,
          y: 450,
          isOnline: true,
          isActive: true,
          settings: { temperature: 68, mode: "cool", schedule: "night" }
        },
        // Apartment Plan devices
        {
          userId,
          floorPlanId: createdUserPlans[1].id,
          kitId: availableKits[1]?.id, // Smart switch
          roomId: "studio",
          name: "Studio Main Switch",
          x: 250,
          y: 200,
          isOnline: true,
          isActive: false,
          settings: { dimLevel: 50, schedule: "manual" }
        }
      ];

      for (const device of userDevicesData) {
        if (device.kitId) { // Only insert if we have a valid kit ID
          await db.insert(userDevices).values(device);
        }
      }

      res.json({ 
        message: "Personal smart home data created successfully",
        summary: {
          floorPlans: createdUserPlans.length,
          devices: userDevicesData.filter(d => d.kitId).length
        }
      });
    } catch (error) {
      console.error("Error seeding user data:", error);
      res.status(500).json({ message: "Failed to seed user data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
