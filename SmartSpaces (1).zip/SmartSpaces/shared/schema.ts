import mongoose from 'mongoose';
import { z } from 'zod';

// Session storage schema for Replit Auth
const sessionSchema = new mongoose.Schema({
  sid: { type: String, required: true, unique: true },
  sess: { type: Object, required: true },
  expire: { type: Date, required: true }
});
sessionSchema.index({ expire: 1 }, { expireAfterSeconds: 0 });

// User schema for Replit Auth
const userSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  email: { type: String, unique: true, sparse: true },
  firstName: String,
  lastName: String,
  profileImageUrl: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Smart kit categories
const kitCategorySchema = new mongoose.Schema({
  name: { type: String, required: true, maxlength: 100 },
  description: String,
  icon: { type: String, maxlength: 50 },
  createdAt: { type: Date, default: Date.now }
});

// Smart kits/modules
const kitSchema = new mongoose.Schema({
  name: { type: String, required: true, maxlength: 200 },
  description: String,
  price: { type: String, required: true }, // Store as string for precision
  categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'KitCategory', required: true },
  specifications: mongoose.Schema.Types.Mixed,
  features: [String],
  connectivity: { type: String, maxlength: 100 },
  icon: { type: String, maxlength: 50 },
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
});

// User floor plans
const floorPlanSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  name: { type: String, required: true, maxlength: 200 },
  description: String,
  rooms: [mongoose.Schema.Types.Mixed], // Stores room layout data
  isDefault: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// User devices (instances of kits in floor plans)
const userDeviceSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  kitId: { type: mongoose.Schema.Types.ObjectId, ref: 'Kit', required: true },
  floorPlanId: { type: mongoose.Schema.Types.ObjectId, ref: 'FloorPlan', required: true },
  name: { type: String, required: true, maxlength: 200 },
  roomId: { type: String, maxlength: 100 },
  x: Number,
  y: Number,
  isOnline: { type: Boolean, default: true },
  isActive: { type: Boolean, default: false },
  settings: mongoose.Schema.Types.Mixed, // Device-specific settings
  lastUpdate: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now }
});

// Models
export const Session = mongoose.model('Session', sessionSchema);
export const User = mongoose.model('User', userSchema);
export const KitCategory = mongoose.model('KitCategory', kitCategorySchema);
export const Kit = mongoose.model('Kit', kitSchema);
export const FloorPlan = mongoose.model('FloorPlan', floorPlanSchema);
export const UserDevice = mongoose.model('UserDevice', userDeviceSchema);

// Validation schemas
export const insertKitCategorySchema = z.object({
  name: z.string().max(100),
  description: z.string().optional(),
  icon: z.string().max(50).optional()
});

export const insertKitSchema = z.object({
  name: z.string().max(200),
  description: z.string().optional(),
  price: z.string(),
  categoryId: z.string(),
  specifications: z.any().optional(),
  features: z.array(z.string()).optional(),
  connectivity: z.string().max(100).optional(),
  icon: z.string().max(50).optional(),
  isActive: z.boolean().optional()
});

export const insertFloorPlanSchema = z.object({
  userId: z.string(),
  name: z.string().max(200),
  description: z.string().optional(),
  rooms: z.array(z.any()).optional(),
  isDefault: z.boolean().optional()
});

export const insertUserDeviceSchema = z.object({
  userId: z.string(),
  kitId: z.string(),
  floorPlanId: z.string(),
  name: z.string().max(200),
  roomId: z.string().max(100).optional(),
  x: z.number().optional(),
  y: z.number().optional(),
  isOnline: z.boolean().optional(),
  isActive: z.boolean().optional(),
  settings: z.any().optional()
});

// Types
export type UpsertUser = {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
};

export type User = {
  _id: string;
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  createdAt: Date;
  updatedAt: Date;
};

export type KitCategory = {
  _id: string;
  name: string;
  description?: string;
  icon?: string;
  createdAt: Date;
};

export type InsertKitCategory = z.infer<typeof insertKitCategorySchema>;

export type Kit = {
  _id: string;
  name: string;
  description?: string;
  price: string;
  categoryId: string;
  specifications?: any;
  features?: string[];
  connectivity?: string;
  icon?: string;
  isActive: boolean;
  createdAt: Date;
};

export type InsertKit = z.infer<typeof insertKitSchema>;

export type FloorPlan = {
  _id: string;
  userId: string;
  name: string;
  description?: string;
  rooms?: any[];
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
};

export type InsertFloorPlan = z.infer<typeof insertFloorPlanSchema>;

export type UserDevice = {
  _id: string;
  userId: string;
  kitId: string;
  floorPlanId: string;
  name: string;
  roomId?: string;
  x?: number;
  y?: number;
  isOnline: boolean;
  isActive: boolean;
  settings?: any;
  lastUpdate: Date;
  createdAt: Date;
};

export type InsertUserDevice = z.infer<typeof insertUserDeviceSchema>;