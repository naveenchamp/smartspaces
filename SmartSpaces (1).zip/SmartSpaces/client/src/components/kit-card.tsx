import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Lightbulb, Shield, Zap, Package, Wifi, Check, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface KitCardProps {
  kit: any;
}

export default function KitCard({ kit }: KitCardProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const getKitIcon = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return Lightbulb;
      case 'running':
      case 'shield-alt':
        return Shield;
      case 'thermometer-half':
      case 'bolt':
        return Zap;
      default:
        return Package;
    }
  };

  const getIconColor = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return 'text-accent-600 bg-accent-50';
      case 'running':
      case 'shield-alt':
        return 'text-red-600 bg-red-50';
      case 'thermometer-half':
      case 'bolt':
        return 'text-secondary-600 bg-secondary-50';
      default:
        return 'text-primary-600 bg-primary-50';
    }
  };

  const Icon = getKitIcon(kit.icon);
  const iconColors = getIconColor(kit.icon);

  const handleAddToPlan = () => {
    toast({
      title: "Added to Floor Plan",
      description: `${kit.name} has been added to your floor plan. Go to the Floor Planner to place it in a room.`,
    });
    setIsDialogOpen(false);
  };

  return (
    <>
      <Card className="group hover:shadow-lg transition-shadow">
        <CardContent className="p-6">
          {/* Kit Icon */}
          <div className={`rounded-xl p-6 mb-6 ${iconColors.split(' ')[1]}`}>
            <Icon className={`text-3xl ${iconColors.split(' ')[0]}`} />
          </div>

          {/* Kit Info */}
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{kit.name}</h3>
          <p className="text-gray-600 mb-4 line-clamp-2">{kit.description}</p>

          {/* Features */}
          <div className="space-y-2 mb-6">
            {kit.features?.slice(0, 3).map((feature: string, index: number) => (
              <div key={index} className="flex items-center text-sm text-gray-600">
                <Check className="text-secondary w-4 h-4 mr-2 flex-shrink-0" />
                {feature}
              </div>
            ))}
          </div>

          {/* Connectivity Badge */}
          <div className="mb-6">
            <Badge variant="secondary" className="flex items-center w-fit">
              <Wifi className="w-3 h-3 mr-1" />
              {kit.connectivity}
            </Badge>
          </div>

          {/* Price and Actions */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-2xl font-bold text-gray-900">${kit.price}</span>
              <span className="text-gray-500 ml-1">/ kit</span>
            </div>
            <div className="flex gap-2">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Info className="w-4 h-4 mr-1" />
                    Details
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${iconColors.split(' ')[1]}`}>
                        <Icon className={`w-6 h-6 ${iconColors.split(' ')[0]}`} />
                      </div>
                      {kit.name}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-6">
                    <p className="text-gray-600">{kit.description}</p>
                    
                    {/* Specifications */}
                    {kit.specifications && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Technical Specifications</h4>
                        <div className="grid md:grid-cols-2 gap-3">
                          {Object.entries(kit.specifications).map(([key, value]: [string, any]) => (
                            <div key={key} className="flex justify-between p-2 bg-gray-50 rounded">
                              <span className="font-medium text-gray-700 capitalize">
                                {key.replace(/([A-Z])/g, ' $1').trim()}:
                              </span>
                              <span className="text-gray-600">{value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Features */}
                    {kit.features && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Features</h4>
                        <div className="space-y-2">
                          {kit.features.map((feature: string, index: number) => (
                            <div key={index} className="flex items-center text-gray-600">
                              <Check className="text-secondary w-4 h-4 mr-2 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Price and Action */}
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div>
                        <span className="text-3xl font-bold text-gray-900">${kit.price}</span>
                        <span className="text-gray-500 ml-1">per kit</span>
                      </div>
                      <Button onClick={handleAddToPlan} className="bg-primary hover:bg-primary/90">
                        Add to Floor Plan
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button onClick={handleAddToPlan} className="bg-primary hover:bg-primary/90">
                Add to Plan
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
