import { useState, useRef } from "react";
import { Undo, Download, MousePointer } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FloorPlanCanvasProps {
  floorPlan: any;
  devices: any[];
  onDeviceDrop: (kit: any, position: { x: number; y: number }, room: string) => void;
}

export default function FloorPlanCanvas({ floorPlan, devices, onDeviceDrop }: FloorPlanCanvasProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    try {
      const kitData = JSON.parse(e.dataTransfer.getData('application/json'));
      const rect = canvasRef.current?.getBoundingClientRect();
      
      if (rect) {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Determine which room the device was dropped in
        const room = getRoomAtPosition(x, y);
        
        onDeviceDrop(kitData, { x, y }, room);
      }
    } catch (error) {
      console.error('Error parsing dropped data:', error);
    }
  };

  const getRoomAtPosition = (x: number, y: number): string => {
    const rooms = floorPlan.layout?.rooms || [];
    
    for (const room of rooms) {
      if (x >= room.x && x <= room.x + room.width &&
          y >= room.y && y <= room.y + room.height) {
        return room.name;
      }
    }
    
    return 'Unknown Room';
  };

  const getDeviceIcon = (device: any) => {
    const iconName = device.kit?.icon;
    switch (iconName) {
      case 'lightbulb':
        return '💡';
      case 'running':
      case 'shield-alt':
        return '🛡️';
      case 'thermometer-half':
      case 'bolt':
        return '🌡️';
      default:
        return '📱';
    }
  };

  const rooms = floorPlan.layout?.rooms || [
    { id: 'living-room', name: 'Living Room', x: 50, y: 50, width: 300, height: 200 },
    { id: 'kitchen', name: 'Kitchen', x: 400, y: 50, width: 200, height: 200 },
    { id: 'bedroom', name: 'Bedroom', x: 50, y: 300, width: 250, height: 180 },
  ];

  return (
    <div className="space-y-4">
      {/* Canvas Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-gray-900">
          {floorPlan.name} - Room Layout
        </h3>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Undo className="w-4 h-4 mr-2" />
            Undo
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Canvas */}
      <div
        ref={canvasRef}
        className={`grid-pattern rounded-xl p-8 min-h-[500px] relative border-2 transition-colors ${
          isDragOver ? 'drag-over' : 'border-gray-200'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {/* Room Layout */}
        <div className="absolute inset-8">
          {rooms.map((room: any) => (
            <div
              key={room.id}
              className="absolute border border-gray-300 rounded bg-blue-50/50 p-4"
              style={{
                left: room.x,
                top: room.y,
                width: room.width,
                height: room.height,
              }}
            >
              <span className="text-sm font-medium text-gray-700">{room.name}</span>
            </div>
          ))}

          {/* Placed Devices */}
          {devices.map((device) => (
            <div
              key={device.id}
              className={`absolute w-8 h-8 rounded-full flex items-center justify-center cursor-pointer shadow-lg text-white text-xs ${
                device.isOnline ? 'bg-primary' : 'bg-gray-400'
              }`}
              style={{
                left: device.position?.x || 100,
                top: device.position?.y || 100,
              }}
              title={`${device.name} (${device.room})`}
            >
              {getDeviceIcon(device)}
            </div>
          ))}
        </div>

        {/* Drop Zone Indicator */}
        <div className="absolute bottom-4 right-4 text-xs text-gray-500 bg-white px-3 py-2 rounded-lg border border-gray-200">
          <MousePointer className="inline w-3 h-3 mr-1" />
          Drag kits from sidebar to place in rooms
        </div>
      </div>

      {/* Device List */}
      {devices.length > 0 && (
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-medium text-gray-900 mb-3">Placed Devices ({devices.length})</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {devices.map((device) => (
              <div
                key={device.id}
                className="flex items-center space-x-2 p-2 bg-white rounded border text-sm"
              >
                <div className={`w-2 h-2 rounded-full ${device.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`}></div>
                <span className="truncate">{device.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
