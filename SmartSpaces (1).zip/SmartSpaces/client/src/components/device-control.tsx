import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Shield, Zap, Package, Wifi, WifiOff } from "lucide-react";

interface DeviceControlProps {
  device: any;
  onToggle: (isActive: boolean) => void;
  isUpdating?: boolean;
}

export default function DeviceControl({ device, onToggle, isUpdating = false }: DeviceControlProps) {
  const getDeviceIcon = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return Lightbulb;
      case 'running':
      case 'shield-alt':
        return Shield;
      case 'thermometer-half':
      case 'bolt':
        return Zap;
      default:
        return Package;
    }
  };

  const getDeviceColors = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return 'bg-accent-100 text-accent-600';
      case 'running':
      case 'shield-alt':
        return 'bg-red-100 text-red-600';
      case 'thermometer-half':
      case 'bolt':
        return 'bg-secondary-100 text-secondary-600';
      default:
        return 'bg-primary-100 text-primary-600';
    }
  };

  const getDeviceStatus = () => {
    if (!device.isOnline) return { text: 'Offline', color: 'text-gray-400' };
    if (device.isActive) return { text: 'Active', color: 'text-emerald-600' };
    return { text: 'Standby', color: 'text-amber-600' };
  };

  const getDeviceValue = () => {
    const kitName = device.kit?.name || '';
    
    if (kitName.includes('Lighting')) {
      return device.isActive ? '75% Brightness' : 'Off';
    }
    if (kitName.includes('Motion') || kitName.includes('Security')) {
      return device.isActive ? 'Armed' : 'Disarmed';
    }
    if (kitName.includes('Climate') || kitName.includes('Thermostat')) {
      return '72°F • 45%';
    }
    return device.isActive ? 'On' : 'Off';
  };

  const Icon = getDeviceIcon(device.kit?.icon);
  const colors = getDeviceColors(device.kit?.icon);
  const status = getDeviceStatus();

  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
      <div className="flex items-center space-x-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colors}`}>
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <p className="font-medium text-gray-900">{device.name}</p>
          <div className="flex items-center space-x-2">
            <p className="text-sm text-gray-600">
              {device.kit?.name} • {device.room}
            </p>
            {device.isOnline ? (
              <Wifi className="w-3 h-3 text-emerald-600" />
            ) : (
              <WifiOff className="w-3 h-3 text-gray-400" />
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="text-right">
          <p className="text-sm font-medium text-gray-900">
            {getDeviceValue()}
          </p>
          <p className={`text-xs ${status.color}`}>
            {status.text}
          </p>
        </div>
        
        <Switch
          checked={device.isActive}
          onCheckedChange={onToggle}
          disabled={!device.isOnline || isUpdating}
          className="data-[state=checked]:bg-secondary"
        />
      </div>
    </div>
  );
}
