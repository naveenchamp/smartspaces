import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/navbar";
import KitCard from "@/components/kit-card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Lightbulb, Shield, Zap, Package } from "lucide-react";
import type { KitCategory, Kit } from "@shared/schema";

export default function Kits() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>("");

  // Get kit categories
  const { data: categories = [] } = useQuery<KitCategory[]>({
    queryKey: ["/api/kit-categories"],
    retry: false,
  });

  // Get kits based on selected category
  const { data: kits = [] } = useQuery<Kit[]>({
    queryKey: selectedCategory ? ["/api/kits", selectedCategory] : ["/api/kits"],
    retry: false,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return Lightbulb;
      case 'shield-alt':
        return Shield;
      case 'bolt':
        return Zap;
      default:
        return Package;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Modular Smart Kits</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional-grade IoT modules designed for easy installation and seamless integration
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center mb-12">
          <div className="bg-gray-100 p-1 rounded-xl">
            <Button
              variant={selectedCategory === "" ? "default" : "ghost"}
              className={`px-6 py-3 rounded-lg font-medium ${
                selectedCategory === "" ? "bg-white shadow-sm text-primary" : "text-gray-600 hover:text-primary"
              }`}
              onClick={() => setSelectedCategory("")}
            >
              <Package className="mr-2 h-4 w-4" />
              All Kits
            </Button>
            
            {categories.map((category) => {
              const Icon = getCategoryIcon(category.icon || '');
              return (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "ghost"}
                  className={`px-6 py-3 rounded-lg font-medium ${
                    selectedCategory === category.id 
                      ? "bg-white shadow-sm text-primary" 
                      : "text-gray-600 hover:text-primary"
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <Icon className="mr-2 h-4 w-4" />
                  {category.name}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Kit Grid */}
        {kits.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {kits.map((kit) => (
              <KitCard key={kit.id} kit={kit} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No kits available</h3>
            <p className="text-gray-600 mb-6">
              {selectedCategory 
                ? "No kits found in this category. Try selecting a different category."
                : "No smart kits are currently available. Please check back later."
              }
            </p>
            {selectedCategory && (
              <Button onClick={() => setSelectedCategory("")}>
                View All Kits
              </Button>
            )}
          </div>
        )}

        {/* CTA Section */}
        <div className="mt-16 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Can't find what you're looking for?
          </h2>
          <p className="text-gray-600 mb-6">
            Our modular system allows for custom configurations. Contact our team for specialized requirements.
          </p>
          <Button className="bg-primary hover:bg-primary/90">
            Contact Support
          </Button>
        </div>
      </main>
    </div>
  );
}
