import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/navbar";
import FloorPlanCanvas from "@/components/floor-plan-canvas";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Lightbulb, Shield, Zap, Save, FolderOpen, Trash2, Plus, Package } from "lucide-react";

export default function Planner() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedFloorPlan, setSelectedFloorPlan] = useState<any>(null);
  const [planName, setPlanName] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Get available kits for dragging
  const { data: kits = [] } = useQuery({
    queryKey: ["/api/kits"],
    retry: false,
  });

  // Get user's floor plans
  const { data: floorPlans = [] } = useQuery({
    queryKey: ["/api/floor-plans"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Get devices for selected floor plan
  const { data: devices = [] } = useQuery({
    queryKey: ["/api/devices", selectedFloorPlan?.id],
    retry: false,
    enabled: !!selectedFloorPlan,
  });

  // Create floor plan mutation
  const createFloorPlanMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string; layout?: any }) => {
      await apiRequest("POST", "/api/floor-plans", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/floor-plans"] });
      toast({
        title: "Success",
        description: "Floor plan created successfully",
      });
      setIsCreateDialogOpen(false);
      setPlanName("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create floor plan",
        variant: "destructive",
      });
    },
  });

  // Update floor plan mutation
  const updateFloorPlanMutation = useMutation({
    mutationFn: async ({ id, layout }: { id: string; layout: any }) => {
      await apiRequest("PUT", `/api/floor-plans/${id}`, { layout });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/floor-plans"] });
      toast({
        title: "Saved",
        description: "Floor plan saved successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save floor plan",
        variant: "destructive",
      });
    },
  });

  // Create device mutation
  const createDeviceMutation = useMutation({
    mutationFn: async (deviceData: any) => {
      await apiRequest("POST", "/api/devices", deviceData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add device",
        variant: "destructive",
      });
    },
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    // Auto-select first floor plan if none selected
    if (floorPlans.length > 0 && !selectedFloorPlan) {
      setSelectedFloorPlan(floorPlans[0]);
    }
  }, [floorPlans, selectedFloorPlan]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getKitIcon = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return Lightbulb;
      case 'running':
      case 'shield-alt':
        return Shield;
      case 'thermometer-half':
      case 'bolt':
        return Zap;
      default:
        return Package;
    }
  };

  const getKitColors = (iconName: string) => {
    switch (iconName) {
      case 'lightbulb':
        return 'bg-accent-100 text-accent-600';
      case 'running':
      case 'shield-alt':
        return 'bg-red-100 text-red-600';
      case 'thermometer-half':
      case 'bolt':
        return 'bg-secondary-100 text-secondary-600';
      default:
        return 'bg-primary-100 text-primary-600';
    }
  };

  const handleCreateFloorPlan = () => {
    if (!planName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a floor plan name",
        variant: "destructive",
      });
      return;
    }

    createFloorPlanMutation.mutate({
      name: planName,
      description: `Floor plan created on ${new Date().toLocaleDateString()}`,
      layout: {
        rooms: [
          { id: 'living-room', name: 'Living Room', x: 50, y: 50, width: 300, height: 200 },
          { id: 'kitchen', name: 'Kitchen', x: 400, y: 50, width: 200, height: 200 },
          { id: 'bedroom', name: 'Bedroom', x: 50, y: 300, width: 250, height: 180 },
        ],
        devices: []
      }
    });
  };

  const handleSaveFloorPlan = () => {
    if (!selectedFloorPlan) return;
    
    // In a real implementation, you'd get the current layout from the canvas
    const currentLayout = selectedFloorPlan.layout || {
      rooms: [
        { id: 'living-room', name: 'Living Room', x: 50, y: 50, width: 300, height: 200 },
        { id: 'kitchen', name: 'Kitchen', x: 400, y: 50, width: 200, height: 200 },
        { id: 'bedroom', name: 'Bedroom', x: 50, y: 300, width: 250, height: 180 },
      ],
      devices: devices.map(device => ({
        id: device.id,
        kitId: device.kitId,
        position: device.position,
        room: device.room
      }))
    };

    updateFloorPlanMutation.mutate({
      id: selectedFloorPlan.id,
      layout: currentLayout
    });
  };

  const handleDeviceDrop = (kit: any, position: { x: number; y: number }, room: string) => {
    createDeviceMutation.mutate({
      kitId: kit.id,
      floorPlanId: selectedFloorPlan.id,
      name: `${kit.name} - ${room}`,
      room,
      position,
      isOnline: true,
      isActive: false,
      settings: {}
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Interactive Floor Planner</h1>
            <p className="text-gray-600">
              Design your smart home layout with drag-and-drop simplicity
            </p>
          </div>
          
          <div className="flex gap-3">
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  New Plan
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Floor Plan</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Enter floor plan name"
                    value={planName}
                    onChange={(e) => setPlanName(e.target.value)}
                  />
                  <div className="flex justify-end gap-3">
                    <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleCreateFloorPlan} disabled={createFloorPlanMutation.isPending}>
                      {createFloorPlanMutation.isPending ? "Creating..." : "Create"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="flex">
            {/* Toolkit Sidebar */}
            <div className="w-80 bg-gray-50 border-r border-gray-200 p-6">
              {/* Floor Plan Selector */}
              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-4">Floor Plans</h3>
                {floorPlans.length > 0 ? (
                  <div className="space-y-2">
                    {floorPlans.map((plan: any) => (
                      <div
                        key={plan.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedFloorPlan?.id === plan.id 
                            ? 'border-primary bg-primary/5' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedFloorPlan(plan)}
                      >
                        <p className="font-medium text-gray-900">{plan.name}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(plan.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <FolderOpen className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600 mb-3">No floor plans yet</p>
                    <Button size="sm" onClick={() => setIsCreateDialogOpen(true)}>
                      Create First Plan
                    </Button>
                  </div>
                )}
              </div>

              {/* Available Kits */}
              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-4">Available Kits</h3>
                <div className="space-y-3">
                  {kits.map((kit: any) => {
                    const Icon = getKitIcon(kit.icon);
                    const colors = getKitColors(kit.icon);
                    
                    return (
                      <div
                        key={kit.id}
                        className="bg-white p-4 rounded-lg border border-gray-200 cursor-move hover:shadow-md transition-shadow"
                        draggable="true"
                        onDragStart={(e) => {
                          e.dataTransfer.setData('application/json', JSON.stringify(kit));
                        }}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colors}`}>
                            <Icon className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{kit.name}</p>
                            <p className="text-sm text-gray-600">${kit.price}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Plan Actions */}
              {selectedFloorPlan && (
                <div className="space-y-3">
                  <Button 
                    onClick={handleSaveFloorPlan} 
                    disabled={updateFloorPlanMutation.isPending}
                    className="w-full bg-primary hover:bg-primary/90"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {updateFloorPlanMutation.isPending ? "Saving..." : "Save Floor Plan"}
                  </Button>
                  <Button variant="outline" className="w-full">
                    <FolderOpen className="w-4 h-4 mr-2" />
                    Load Saved Plan
                  </Button>
                  <Button variant="outline" className="w-full text-gray-600">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                </div>
              )}
            </div>

            {/* Floor Plan Canvas */}
            <div className="flex-1 p-6">
              {selectedFloorPlan ? (
                <FloorPlanCanvas
                  floorPlan={selectedFloorPlan}
                  devices={devices}
                  onDeviceDrop={handleDeviceDrop}
                />
              ) : (
                <div className="flex items-center justify-center h-96 bg-gray-100 rounded-xl">
                  <div className="text-center">
                    <FolderOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Floor Plan Selected</h3>
                    <p className="text-gray-600 mb-6">Create a new floor plan or select an existing one to start designing.</p>
                    <Button onClick={() => setIsCreateDialogOpen(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Create New Floor Plan
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
