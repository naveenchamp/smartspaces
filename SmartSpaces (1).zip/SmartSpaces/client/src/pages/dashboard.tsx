import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/navbar";
import DeviceControl from "@/components/device-control";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { BarChart3, Wifi, Zap, Moon, Home, AlertTriangle, Package } from "lucide-react";
import type { UserDevice } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Get user devices
  const { data: devices = [] } = useQuery<UserDevice[]>({
    queryKey: ["/api/devices"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Update device mutation
  const updateDeviceMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      await apiRequest("PUT", `/api/devices/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update device",
        variant: "destructive",
      });
    },
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const activeDevices = devices.filter((device: any) => device.isOnline);
  const onlineDevices = devices.filter((device: any) => device.isOnline && device.isActive);
  const totalEnergyUsage = onlineDevices.length * 0.8; // Mock calculation

  const handleDeviceToggle = (deviceId: string, isActive: boolean) => {
    updateDeviceMutation.mutate({
      id: deviceId,
      updates: { isActive }
    });
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'night-mode':
        devices.forEach((device: any) => {
          if (device.kit?.icon === 'lightbulb') {
            updateDeviceMutation.mutate({
              id: device.id,
              updates: { isActive: false }
            });
          }
        });
        toast({
          title: "Night Mode Activated",
          description: "All lights have been turned off",
        });
        break;
      case 'away-mode':
        devices.forEach((device: any) => {
          if (device.kit?.icon === 'shield-alt') {
            updateDeviceMutation.mutate({
              id: device.id,
              updates: { isActive: true }
            });
          } else {
            updateDeviceMutation.mutate({
              id: device.id,
              updates: { isActive: false }
            });
          }
        });
        toast({
          title: "Away Mode Activated",
          description: "Security devices armed, other devices turned off",
        });
        break;
      case 'emergency':
        toast({
          title: "Emergency Mode",
          description: "Emergency protocols activated. All devices secured.",
          variant: "destructive",
        });
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Device Dashboard</h1>
          <p className="text-gray-600">
            Monitor and control all your smart devices from one place
          </p>
        </div>

        {devices.length === 0 ? (
          <Card className="p-8 text-center">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No Devices Connected</h3>
            <p className="text-gray-600 mb-6">
              Add some smart kits to your floor plan to start controlling devices.
            </p>
            <div className="flex justify-center gap-3">
              <Button onClick={() => window.location.href = "/kits"}>
                Browse Smart Kits
              </Button>
              <Button variant="outline" onClick={() => window.location.href = "/planner"}>
                Floor Planner
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Device Controls */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Active Devices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {devices.map((device: any) => (
                      <DeviceControl
                        key={device.id}
                        device={device}
                        onToggle={(isActive) => handleDeviceToggle(device.id, isActive)}
                        isUpdating={updateDeviceMutation.isPending}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar Stats */}
            <div className="space-y-6">
              {/* System Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">System Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Active Devices</span>
                      <span className="font-semibold text-gray-900">
                        {activeDevices.length}/{devices.length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Network</span>
                      <span className="flex items-center text-secondary">
                        <div className="w-2 h-2 bg-secondary rounded-full mr-2"></div>
                        Online
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Last Update</span>
                      <span className="text-gray-900">
                        {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Energy Usage */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    Energy Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 mb-2">
                      {totalEnergyUsage.toFixed(1)} kWh
                    </div>
                    <p className="text-sm text-gray-600 mb-4">Today's consumption</p>
                    <div className="bg-secondary/20 rounded-full h-2 mb-2">
                      <div 
                        className="bg-secondary h-2 rounded-full transition-all" 
                        style={{ width: `${Math.min((totalEnergyUsage / 4) * 100, 100)}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-gray-500">
                      {Math.min(Math.round((totalEnergyUsage / 4) * 100), 100)}% of daily target
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleQuickAction('night-mode')}
                    >
                      <Moon className="w-4 h-4 mr-2" />
                      Night Mode
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => handleQuickAction('away-mode')}
                    >
                      <Home className="w-4 h-4 mr-2" />
                      Away Mode
                    </Button>
                    <Button 
                      variant="destructive" 
                      className="w-full justify-start"
                      onClick={() => handleQuickAction('emergency')}
                    >
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      Emergency
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
