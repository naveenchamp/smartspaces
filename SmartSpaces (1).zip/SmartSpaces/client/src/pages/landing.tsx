import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Home, Lightbulb, Shield, Zap, Wifi, Package, Map, Smartphone } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-secondary/5">
      {/* Navigation Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Home className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">SMARTHABITAT</h1>
                <p className="text-xs text-gray-500">Smart Living, Assembled</p>
              </div>
            </div>
            
            <Button 
              onClick={() => window.location.href = "/api/login"}
              className="bg-primary hover:bg-primary/90"
            >
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl font-bold text-gray-900 mb-6 leading-tight">
                Smart Living,<br />
                <span className="text-primary">Assembled.</span>
              </h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Build your perfect smart home with our modular IoT kits. Design, install, and control every aspect of your connected living space.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg"
                  onClick={() => window.location.href = "/api/login"}
                  className="bg-primary hover:bg-primary/90"
                >
                  Browse Smart Kits
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => window.location.href = "/api/login"}
                >
                  Try Floor Planner
                </Button>
              </div>
            </div>
            
            <div className="relative">
              <Card className="p-8 relative overflow-hidden">
                <div className="grid grid-cols-3 gap-6">
                  <div className="bg-accent/10 p-4 rounded-xl text-center">
                    <Lightbulb className="text-accent mx-auto text-2xl mb-2" />
                    <p className="text-sm font-medium text-gray-700">Lighting</p>
                    <div className="w-8 h-4 bg-secondary rounded-full mt-2 mx-auto"></div>
                  </div>
                  <div className="bg-red-50 p-4 rounded-xl text-center">
                    <Shield className="text-red-600 mx-auto text-2xl mb-2" />
                    <p className="text-sm font-medium text-gray-700">Security</p>
                    <div className="w-8 h-4 bg-secondary rounded-full mt-2 mx-auto"></div>
                  </div>
                  <div className="bg-secondary/10 p-4 rounded-xl text-center">
                    <Zap className="text-secondary mx-auto text-2xl mb-2" />
                    <p className="text-sm font-medium text-gray-700">Energy</p>
                    <div className="w-8 h-4 bg-secondary rounded-full mt-2 mx-auto"></div>
                  </div>
                </div>
                <div className="absolute top-4 right-4 w-3 h-3 bg-secondary rounded-full animate-pulse"></div>
                <div className="text-xs text-secondary font-medium mt-4 text-center">
                  <Wifi className="inline w-3 h-3 mr-1" />
                  All devices connected
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose SmartHabitat?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional-grade IoT solutions designed for easy installation and seamless integration
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Modular Design</h3>
              <p className="text-gray-600">Mix and match kits based on your needs. Start small and expand over time.</p>
            </Card>

            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-secondary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Map className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Visual Planning</h3>
              <p className="text-gray-600">Drag-and-drop floor planner helps you design the perfect smart home layout.</p>
            </Card>

            <Card className="p-6 text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Smartphone className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Easy Control</h3>
              <p className="text-gray-600">Monitor and control all devices from a single dashboard on any device.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of homeowners building smarter, more connected living spaces.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = "/api/login"}
            className="bg-primary hover:bg-primary/90"
          >
            Start Building Your Smart Home
          </Button>
        </div>
      </section>
    </div>
  );
}
