import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Package, Map, BarChart3, Home, Lightbulb, Shield, Zap, ArrowRight } from "lucide-react";
import type { User, FloorPlan, UserDevice } from "@shared/schema";

export default function HomePage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth() as { 
    isAuthenticated: boolean; 
    isLoading: boolean; 
    user: User | undefined; 
  };

  // Get user's floor plans and devices
  const { data: floorPlans = [] } = useQuery<FloorPlan[]>({
    queryKey: ["/api/floor-plans"],
    retry: false,
    enabled: isAuthenticated,
  });

  const { data: devices = [] } = useQuery<UserDevice[]>({
    queryKey: ["/api/devices"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const activeDevices = devices.filter((device) => device.isOnline);
  const onlineDevices = devices.filter((device) => device.isOnline && device.isActive);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back{user?.firstName ? `, ${user.firstName}` : ''}!
          </h1>
          <p className="text-gray-600">
            Manage your smart home devices and floor plans from your dashboard.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-primary" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Floor Plans</p>
                <p className="text-2xl font-bold text-gray-900">{floorPlans.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                <Package className="w-6 h-6 text-secondary" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Devices</p>
                <p className="text-2xl font-bold text-gray-900">{activeDevices.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-emerald-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Online</p>
                <p className="text-2xl font-bold text-gray-900">{onlineDevices.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-accent" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Status</p>
                <p className="text-lg font-bold text-emerald-600">All Good</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
            </div>
            
            <div className="space-y-3">
              <Link href="/kits">
                <Button variant="outline" className="w-full justify-start">
                  <Package className="w-4 h-4 mr-2" />
                  Browse Smart Kits
                  <ArrowRight className="w-4 h-4 ml-auto" />
                </Button>
              </Link>
              
              <Link href="/planner">
                <Button variant="outline" className="w-full justify-start">
                  <Map className="w-4 h-4 mr-2" />
                  Floor Planner
                  <ArrowRight className="w-4 h-4 ml-auto" />
                </Button>
              </Link>
              
              <Link href="/dashboard">
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Device Dashboard
                  <ArrowRight className="w-4 h-4 ml-auto" />
                </Button>
              </Link>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Recent Floor Plans</h3>
              <Link href="/planner">
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </div>
            
            {floorPlans.length > 0 ? (
              <div className="space-y-3">
                {floorPlans.slice(0, 3).map((plan) => (
                  <div key={plan.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{plan.name}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(plan.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Link href="/planner">
                      <Button variant="ghost" size="sm">Edit</Button>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Map className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">No floor plans yet</p>
                <Link href="/planner">
                  <Button>Create Your First Plan</Button>
                </Link>
              </div>
            )}
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Device Status</h3>
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </div>
            
            {devices.length > 0 ? (
              <div className="space-y-3">
                {devices.slice(0, 3).map((device) => (
                  <div key={device.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        device.isOnline ? 'bg-emerald-100' : 'bg-gray-200'
                      }`}>
                        {device.kit?.icon === 'lightbulb' && <Lightbulb className={`w-4 h-4 ${device.isOnline ? 'text-emerald-600' : 'text-gray-400'}`} />}
                        {device.kit?.icon === 'shield-alt' && <Shield className={`w-4 h-4 ${device.isOnline ? 'text-emerald-600' : 'text-gray-400'}`} />}
                        {device.kit?.icon === 'thermometer-half' && <Zap className={`w-4 h-4 ${device.isOnline ? 'text-emerald-600' : 'text-gray-400'}`} />}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{device.name}</p>
                        <p className="text-sm text-gray-600">{device.room}</p>
                      </div>
                    </div>
                    <div className={`w-2 h-2 rounded-full ${device.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`}></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">No devices connected</p>
                <Link href="/kits">
                  <Button>Browse Smart Kits</Button>
                </Link>
              </div>
            )}
          </Card>
        </div>

        {/* Getting Started */}
        {floorPlans.length === 0 && devices.length === 0 && (
          <Card className="p-8 text-center">
            <div className="max-w-md mx-auto">
              <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-6">
                <Home className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Welcome to SmartHabitat!</h3>
              <p className="text-gray-600 mb-6">
                Start building your smart home by browsing our modular IoT kits or create your first floor plan.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link href="/kits">
                  <Button>Browse Smart Kits</Button>
                </Link>
                <Link href="/planner">
                  <Button variant="outline">Create Floor Plan</Button>
                </Link>
              </div>
            </div>
          </Card>
        )}
      </main>
    </div>
  );
}
